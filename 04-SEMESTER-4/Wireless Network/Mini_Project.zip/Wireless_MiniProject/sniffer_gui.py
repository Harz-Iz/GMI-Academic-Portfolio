import threading
import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
# ADDED: wrpcap to the imports to handle PCAP generation
from scapy.all import sniff, Dot11Deauth, Dot11, Dot11Elt, Dot11Auth, wrpcap

class WiFiSnifferApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Wireless Lab Sniffer & Threat Detector")
        self.root.geometry("850x460") # Slightly increased height for the button layout
        
        # Dictionary to map BSSID (AP MAC) -> SSID string dynamically
        self.bssid_to_ssid = {}
        
        # ADDED: List to store actual Scapy packet objects for PCAP export
        self.captured_packets = []
        
        # Intercept the GUI 'X' close button to exit cleanly
        self.root.protocol("WM_DELETE_WINDOW", self.force_exit)
        
        # Status Bar
        self.status_label = tk.Label(root, text="Sniffing on wlan2 (Channel 6)...", font=("Arial", 11), fg="green")
        self.status_label.pack(pady=5)
        
        # Event Log Window
        self.tree = ttk.Treeview(root, columns=("Type", "SSID", "Source (AP)", "Destination (Client)", "Code"), show='headings')
        self.tree.heading("Type", text="Event Type")
        self.tree.heading("SSID", text="SSID")
        self.tree.heading("Source (AP)", text="Source MAC")
        self.tree.heading("Destination (Client)", text="Destination MAC")
        self.tree.heading("Code", text="Code (Reason/Status)")
        
        # Format column widths for optimal scannability
        self.tree.column("Type", width=130, anchor="center")
        self.tree.column("SSID", width=160, anchor="w")
        self.tree.column("Source (AP)", width=140, anchor="center")
        self.tree.column("Destination (Client)", width=140, anchor="center")
        self.tree.column("Code", width=130, anchor="center")
        
        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # ADDED: Export Button Control Frame & Button
        self.btn_frame = tk.Frame(root)
        self.btn_frame.pack(pady=10)
        
        self.save_button = tk.Button(
            self.btn_frame, 
            text="💾 Export Captured Packets to PCAP", 
            command=self.save_to_pcap, 
            font=("Arial", 10, "bold"), 
            bg="#2196F3", 
            fg="white", 
            padx=10, 
            pady=5
        )
        self.save_button.pack()
        
        # Start sniffing thread
        self.sniffer_thread = threading.Thread(target=self.start_sniffing, daemon=True)
        self.sniffer_thread.start()

    def packet_callback(self, pkt):
        try:
            if not pkt.haslayer(Dot11):
                return

            # 1. DYNAMIC LOOKUP: Learn SSIDs silently from Beacon (subtype 8) or Probe Responses (subtype 5)
            if pkt.type == 0 and pkt.subtype in [5, 8]:
                if pkt.haslayer(Dot11Elt):
                    try:
                        ssid = pkt[Dot11Elt].info.decode(errors="ignore")
                        bssid = pkt[Dot11].addr3
                        
                        if ssid and bssid and bssid not in self.bssid_to_ssid:
                            self.bssid_to_ssid[bssid] = ssid
                    except:
                        pass

            # 2. CATCH DEAUTHENTICATION ATTACKS
            elif pkt.haslayer(Dot11Deauth):
                dst = pkt[Dot11].addr1  
                src = pkt[Dot11].addr2  
                bssid = pkt[Dot11].addr3
                reason = pkt[Dot11Deauth].reason
                
                ssid = self.bssid_to_ssid.get(bssid, "Locating SSID...")
                code_display = f"Reason: {reason}"
                
                # ADDED: Store raw packet for PCAP generation
                self.captured_packets.append(pkt)
                self.root.after(0, self.log_alert, "DEAUTH ATTACK", ssid, src, dst, code_display)
                
            # 3. CATCH AUTHENTICATION REQUESTS/RESPONSES
            elif pkt.type == 0 and pkt.subtype == 11:
                dst = pkt[Dot11].addr1
                src = pkt[Dot11].addr2
                bssid = pkt[Dot11].addr3
                
                ssid = self.bssid_to_ssid.get(bssid, "Locating SSID...")
                
                if pkt.haslayer(Dot11Auth):
                    status_code = pkt[Dot11Auth].status
                    code_display = f"Status: {status_code}"
                else:
                    code_display = "Status: Unknown"
                
                # ADDED: Store raw packet for PCAP generation
                self.captured_packets.append(pkt)
                self.root.after(0, self.log_alert, "Auth Request/Resp", ssid, src, dst, code_display)
                
        except Exception as e:
            print(f"[-] Parsing error: {e}")

    def log_alert(self, event_type, ssid, src, dst, reason):
        self.tree.insert("", 0, values=(event_type, ssid, src, dst, reason))

    # ADDED: Method to handle file dialog window and compile the PCAP file via Scapy
    def save_to_pcap(self):
        if not self.captured_packets:
            messagebox.showwarning("No Data", "There are no threat/auth packets captured yet to save!")
            return
        
        # Open standard OS Save As window
        file_path = filedialog.asksaveasfilename(
            defaultextension=".pcap",
            filetypes=[("PCAP files", "*.pcap"), ("All files", "*.*")],
            title="Save Wireshark PCAP File"
        )
        
        if file_path:
            try:
                # Use Scapy's native writer to compile the stored list of packets
                wrpcap(file_path, self.captured_packets)
                messagebox.showinfo("Success", f"Successfully saved {len(self.captured_packets)} packets to:\n{file_path}")
            except Exception as e:
                messagebox.showerror("Export Error", f"Failed to save PCAP file:\n{e}")

    def start_sniffing(self):
        # Kept store=0 so Scapy doesn't leak global memory indefinitely, 
        # as we are selectively logging target frames into self.captured_packets manually.
        sniff(iface="wlan2", prn=self.packet_callback, store=0)

    def force_exit(self):
        print("\n[*] Shutting down sniffer application cleanly...")
        self.root.destroy()
        os._exit(0)

def keep_interpreter_alive():
    root.after(200, keep_interpreter_alive)

if __name__ == "__main__":
    root = tk.Tk()
    app = WiFiSnifferApp(root)
    root.after(200, keep_interpreter_alive)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("\n[*] Ctrl+C detected.")
        app.force_exit()
