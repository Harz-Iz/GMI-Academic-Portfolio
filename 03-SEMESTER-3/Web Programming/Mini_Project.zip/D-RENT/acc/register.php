<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Save new user into users.txt
    $file = fopen("users.txt", "a");
    fwrite($file, "$user,$pass\n");
    fclose($file);

    header("Location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register - Luxury Rentals</title>
  <link rel="stylesheet" href="../style.css">
</head>

<body>
<?php include("../header.php"); ?>
<h2>Register</h2>
<form method="POST" class="form-box">
  <input type="text" name="username" placeholder="Choose Username" required><br>
  <input type="password" name="password" placeholder="Choose Password" required><br>
  <button type="submit" class="btn">Register</button>
</form>
<a href="login.php" class="btn">Back</a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include("../footer.php"); ?>
</body>
</html>
