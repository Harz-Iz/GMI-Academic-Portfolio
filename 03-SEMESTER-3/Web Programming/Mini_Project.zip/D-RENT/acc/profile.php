<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include("../header.php");

// feedback form 
$feedbackMsg = "";
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['feedback_text'])) {
    $to = "c3rberix@gmail.com"; // accepter
    $subject = "Website Feedback from " . ($_SESSION['user'] ?? 'Guest');
    $message = "Name: " . ($_SESSION['user'] ?? 'Guest') . "\nFeedback: " . strip_tags($_POST['feedback_text']);

    $fromEmail = "c3rberix@gmail.com"; // sender
    $headers = "From: Luxury D-RENT <{$fromEmail}>\r\n";

    if (mail($to, $subject, $message, $headers)) {
        $feedbackMsg = "<p style='color:green;'>Feedback sent successfully.</p>";
    } else {
        $feedbackMsg = "<p style='color:red;'>Feedback could not be sent. (Mail server not configured locally)</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Profile</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<h2>Profile</h2>

<form class="form-box" method="POST" enctype="multipart/form-data">
  <!-- simple form (tk save pape pun) -->
  <label>Full Name:</label><br>
  <input type="text" name="fullname" required><br>

  <label>Password:</label><br>
  <input type="password" name="password" required><br>

  <label>Email:</label><br>
  <input type="email" name="email" required><br>

  <label>Age:</label><br>
  <input type="number" name="age" min="18" max="100"><br>

  <label>Date of Birth:</label><br>
  <input type="date" name="dob"><br>

  <br>

  <label>Gender:</label><br>
  <div class="inline-options">
    <label><input type="radio" name="gender" value="male"> Male</label>
    <label><input type="radio" name="gender" value="female"> Female</label>
    <label><input type="radio" name="gender" value="other"> Other</label>
  </div>

  <br>
  <br>

  <label>Preferences:</label><br>
  <div class="inline-options">
    <label><input type="checkbox" name="pref[]" value="email"> Email Updates</label>
    <label><input type="checkbox" name="pref[]" value="sms"> SMS Alerts</label>
    <label><input type="checkbox" name="pref[]" value="promo"> Promotions</label>
  </div>

  <br>
  <br>

  <label>Upload Driving License:</label><br>
  <input type="file" name="license"><br>

  <label>Rental Satisfaction (1-10):</label><br>
  <input type="range" min="1" max="10" name="satisfaction"><br>

  <label>Favourite Car Colour:</label><br>
  <input type="color" name="favcolor"><br>

  <br>

  <label>Preferred Car Type (Dropdown):</label><br>
  <br>
  <select name="car_type">
    <option value="supercar">Supercar</option>
    <option value="luxury">Luxury Sedan</option>
    <option value="suv">SUV</option>
    <option value="bike">Superbike</option>
  </select><br>

  <br>

  <label>Personal Website (if any):</label><br>
  <input type="url" name="website"><br>

  <input type="hidden" name="user_id" value="123">

  <button type="submit" class="btn">Submit</button>
</form>


<hr style="margin:40px 0;">
<br>


<!-- Render Feedback Form -->
<h2>Give Us Your Feedback</h2>
<?php echo $feedbackMsg; ?>
<form method="POST" class="form-box">
    <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['user'] ?? 'Guest'); ?></p>
    <textarea name="feedback_text" rows="5" style="width:90%;" placeholder="Your feedback here..." required></textarea><br>
    <button type="submit" class="btn">Send Feedback</button>
</form>
<br>
<br>
<br>
<br>

<?php include("../footer.php"); ?>
</body>
</html>
