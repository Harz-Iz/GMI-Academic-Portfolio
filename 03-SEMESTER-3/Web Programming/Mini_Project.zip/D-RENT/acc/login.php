<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $user = $_POST['username'];
  $pass = $_POST['password'];

  // Load "users" from a simple text file (simulate database)
  $users = file("users.txt", FILE_IGNORE_NEW_LINES);
  $valid = false;
  foreach ($users as $u) {
    list($uname, $upass) = explode(",", $u);
    if ($uname == $user && $upass == $pass) {
      $valid = true;
      break;
    }
  }

  if ($valid) {
    $_SESSION['user'] = $user;
    header("Location: ../index.php");
  } else {
    $error = "Invalid credentials!";
  }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Login - Luxury Rentals</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<?php include("../header.php"); ?>
<h2>Login</h2>
<?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
<form method="POST" class="form-box">
  <input type="text" name="username" placeholder="Username" required><br>
  <input type="password" name="password" placeholder="Password" required><br>
  <button type="submit" class="btn">Login</button>
</form>
<p>Don't have an account? <a href="register.php">Register here</a></p>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include("../footer.php"); ?>
</body>
</html>
