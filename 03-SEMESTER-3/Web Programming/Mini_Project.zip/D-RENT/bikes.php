<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// if no active login, redirect to login page
if (!isset($_SESSION['user'])) {
    header("Location: acc/login.php");
    exit;
}
?>

<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Superbikes - Luxury Rentals</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Superbikes</h2>
<div class="showcase">
<?php
$bikes = [
  ["id"=>101, "name"=>"Ducati Panigale V4R (2023)", "price"=>1120, "img"=>"bike2.jpg"],
  ["id"=>102, "name"=>"Yamaha YZF-R1M (2024)", "price"=>990, "img"=>"bike4.jpg"],
  ["id"=>103, "name"=>"BMW S1000RR (2020)", "price"=>857, "img"=>"bike3.jpg"]
];
foreach($bikes as $b){
  echo "<div class='card'>
    <img src='images/{$b['img']}' alt='{$b['name']}'>
    <h3>{$b['name']}</h3>
    <p>RM {$b['price']} / day</p>
    <a href='fin/cart.php?id={$b['id']}&type=bike' class='btn'>Rent Now</a>
  </div>";
}
?>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include("footer.php"); ?>
</body>
</html>
