<footer class="site-footer">
  <div class="footer-content">
    <div class="footer-left">
      <p>© <?php echo date('Y'); ?> Diamond Rent Inc.</p><p>Website Developed by : DCBS1 / SEM 3 (2025) <!-- Abdul Hariz Mohd Sarnudin :P --></p>
    </div>
    <div class="footer-right">
      <a href="https://www.linkedin.com/in/abdharizsarnudin/" target="_blank">
        <img src="/D-RENT/images/logo/linkedin.png" alt="LinkedIn" class="social-icon">
      </a>
      <a href="http://vlu.gmi.edu.my/course/view.php?id=1261" target="_blank">
        <img src="/D-RENT/images/logo/gmi.png" alt="GMI" class="social-icon">
    </a>
      <a href="https://chat.whatsapp.com/HElVIyj9GHPKu6o3y8mCIc" target="_blank">
        <img src="/D-RENT/images/logo/whatsapp.png" alt="Whatsapp" class="social-icon">
    </a>

    </div>
  </div>
</footer>
