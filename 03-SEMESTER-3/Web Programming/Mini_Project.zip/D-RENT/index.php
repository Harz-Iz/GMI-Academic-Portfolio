<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// if no active login, redirect to login page
if (!isset($_SESSION['user'])) {
    header("Location: acc/login.php");
    exit;
}
?>

<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Luxury Rentals</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Welcome to Luxury Rentals</h1>

<!-- Slideshow -->
<div class="slideshow">
  <img src="images/car1.jpg" class="slide" style="display:block;">
  <img src="images/bike1.jpg" class="slide" style="display:block;">
  <img src="images/car2.jpg" class="slide" style="display:block;">
  <img src="images/bike4.jpg" class="slide" style="display:block;">
  <img src="images/car4.jpg" class="slide" style="display:block;">
  <img src="images/bike2.jpg" class="slide" style="display:block;">
</div>

<script src="slideshow.js"></script>

<!-- Showcase Section -->
<section class="showcase">
  <h2>Featured Supercars</h2>
  <?php
  $cars = [
    ["id"=>261, "name"=>"Lamborghini Huracán", "price"=>5500, "img"=>"car5.jpg"],
    ["id"=>278, "name"=>"Hennessey Venom F5", "price"=>25000, "img"=>"car3.jpg"]
  ];
  foreach($cars as $c){
    echo "<div class='card'>
      <img src='images/{$c['img']}' alt='{$c['name']}'>
      <h3>{$c['name']}</h3>
      <p>RM {$c['price']} / day</p>
      <a href='fin/cart.php?id={$c['id']}&type=car' class='btn'>Rent Now</a>
    </div>";
  }
  ?>
  <a href="cars.php" class="link-more">View All Supercars →</a>
</section>

<section class="showcase">
  <h2>Featured Superbikes</h2>
  <?php
  $bikes = [
    ["id"=>102, "name"=>"Yamaha R1", "price"=>990, "img"=>"bike4.jpg"],
    ["id"=>103, "name"=>"BMW S1000RR", "price"=>857, "img"=>"bike3.jpg"]
  ];
  foreach($bikes as $b){
    echo "<div class='card'>
      <img src='images/{$b['img']}' alt='{$b['name']}'>
      <h3>{$b['name']}</h3>
      <p>RM {$b['price']} / day</p>
      <a href='fin/cart.php?id={$b['id']}&type=bike' class='btn'>Rent Now</a>
    </div>";
  }
  ?>
  <a href="bikes.php" class="link-more">View All Superbikes →</a>
</section>
<?php include("footer.php"); ?>
</body>
</html>
