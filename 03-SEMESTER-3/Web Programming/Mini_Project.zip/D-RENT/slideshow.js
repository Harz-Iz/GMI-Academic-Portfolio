let idx = 0;
function showSlides() {
  let slides = document.querySelectorAll(".slide");
  slides.forEach(s => s.style.display = "none");
  idx = (idx + 1) % slides.length;
  slides[idx].style.display = "block";
  setTimeout(showSlides, 3000);
}
showSlides();
