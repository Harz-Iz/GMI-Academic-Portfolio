<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav>
  <a href="/D-RENT/index.php">Home</a>
  <a href="/D-RENT/cars.php">Supercars</a>
  <a href="/D-RENT/bikes.php">Superbikes</a>
  <a href="/D-RENT/fin/cart.php">Cart</a>
  <?php if(isset($_SESSION['user'])): ?>
    <a href="/D-RENT/acc/profile.php">Profile</a>
    <a href="/D-RENT/acc/logout.php">Logout (<?php echo $_SESSION['user']; ?>)</a>
  <?php else: ?>
    <a href="/D-RENT/acc/login.php">Login</a>
  <?php endif; ?>
</nav>
<hr>

