<?php
// receipt.php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../acc/login.php");
    exit;
}

// Get POSTed values (from checkout)
$name = isset($_POST['fullname']) ? trim($_POST['fullname']) : (isset($_SESSION['user']) ? $_SESSION['user'] : 'Guest');
$days = isset($_POST['days']) ? intval($_POST['days']) : (isset($_SESSION['receipt_days']) ? intval($_SESSION['receipt_days']) : 1);

// Snapshot the cart and input data so PDF generator can use the same data
$_SESSION['receipt_fullname'] = $name;
$_SESSION['receipt_days'] = $days;
$_SESSION['receipt_snapshot'] = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Receipt - Luxury D-RENT</title>
  <link rel="stylesheet" href="../style.css">

</head>
<body>
<?php include '../header.php'; ?>

<div class="receipt-container">
    <div class="receipt-header">
        <h2>Luxury D-RENT</h2>
        <p class="meta">Your Rental Receipt</p>
        <p class="meta">Customer: <?php echo htmlspecialchars($name); ?> &nbsp;|&nbsp; Days: <?php echo $days; ?></p>
    </div>

    <div class="receipt-items">
        <table>
            <tr><th>Item</th><th>Price / day</th><th>Days</th><th>Subtotal</th></tr>
            <?php
            $total = 0.0;
            $snapshot = isset($_SESSION['receipt_snapshot']) ? $_SESSION['receipt_snapshot'] : [];
            if (!empty($snapshot)) {
                foreach ($snapshot as $item) {
                    $iname = isset($item['name']) ? $item['name'] : 'Unknown Item';
                    $iprice = isset($item['price']) ? floatval($item['price']) : 0.0;
                    $subtotal = $iprice * $days;
                    $total += $subtotal;
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($iname) . "</td>";
                    echo "<td>RM " . number_format($iprice, 2) . "</td>";
                    echo "<td>" . intval($days) . "</td>";
                    echo "<td>RM " . number_format($subtotal, 2) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No items in cart</td></tr>";
            }
            ?>
        </table>
    </div>

    <p class="total">Total: RM <?php echo number_format($total, 2); ?></p>

    <div style="margin-top:18px;">
        <a href="receipt_pdf.php" target="_blank" class="download-btn">Download PDF</a>
    </div>
</div>
<?php include("../footer.php"); ?>
</body>
</html>
