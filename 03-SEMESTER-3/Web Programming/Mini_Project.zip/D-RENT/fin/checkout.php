<?php include("../header.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Checkout - Luxury Rentals</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<h2>Checkout</h2>
<form method="POST" action="receipt.php" class="form-box">
  <input type="text" name="fullname" placeholder="Full Name" required><br>
  <input type="number" name="days" placeholder="Number of days" required><br>
  <button type="submit" class="btn">Confirm Rental</button>
</form>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include("../footer.php"); ?>
</body>
</html>
