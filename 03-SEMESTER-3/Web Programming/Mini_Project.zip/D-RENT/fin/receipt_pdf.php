<?php
// receipt_pdf.php
if (session_status() === PHP_SESSION_NONE) session_start();

// make sure snapshot exists
if (!isset($_SESSION['receipt_snapshot'])) {
    header("Location: cart.php");
    exit;
}

$items = $_SESSION['receipt_snapshot'];
$days = isset($_SESSION['receipt_days']) ? intval($_SESSION['receipt_days']) : 1;
$fullname = isset($_SESSION['receipt_fullname']) ? $_SESSION['receipt_fullname'] : (isset($_SESSION['user']) ? $_SESSION['user'] : 'Guest');

// require FPDF (make sure folder fpdf/ is in your project)
require('fpdf/fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->SetTextColor(0,0,0);

// Header
$pdf->SetFillColor(212,175,55);
$pdf->Cell(0,10,'Luxury D-RENT Receipt',0,1,'C',false);
$pdf->Ln(3);

// Customer & meta
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,6,'Customer: ' . $fullname,0,1);
$pdf->Cell(0,6,'Days: ' . $days,0,1);
$pdf->Ln(5);

// Table header
$pdf->SetFont('Arial','B',11);
$pdf->Cell(85,9,'Item',1,0,'L');
$pdf->Cell(30,9,'Price/day',1,0,'R');
$pdf->Cell(20,9,'Days',1,0,'C');
$pdf->Cell(40,9,'Subtotal',1,0,'R');
$pdf->Ln();

$pdf->SetFont('Arial','',11);
$total = 0.0;

foreach ($items as $item) {
    $iname = isset($item['name']) ? $item['name'] : 'Unknown Item';
    $iprice = isset($item['price']) ? floatval($item['price']) : 0.0;
    $subtotal = $iprice * $days;
    // cells
    $pdf->Cell(85,8,substr($iname,0,40),1,0,'L');
    $pdf->Cell(30,8,number_format($iprice,2),1,0,'R');
    $pdf->Cell(20,8,$days,1,0,'C');
    $pdf->Cell(40,8,number_format($subtotal,2),1,0,'R');
    $pdf->Ln();
    $total += $subtotal;
}

// Total row
$pdf->SetFont('Arial','B',12);
$pdf->Cell(135,10,'Total (RM)',1,0,'R');
$pdf->Cell(40,10,number_format($total,2),1,0,'R');

$pdf->Ln(12);
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,6,'Thank you for choosing Luxury D-RENT.',0,1);

// Output the PDF inline (I) or force download (D). I prefer inline preview:
$pdf->Output('I','D-RENT-Receipt.pdf');
exit;
