<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// if no active login, redirect to login page
if (!isset($_SESSION['user'])) {
    header("Location: ../acc/login.php");
    exit;
}
?>

<?php
include("../header.php");

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

// Vehicle data (central place)
$items = [
  101 => ["name"=>"Ducati Panigale V4R (2023)", "price"=>1120, "img"=>"bike2.jpg"],
  102 => ["name"=>"Yamaha YZF-R1M (2024)", "price"=>990, "img"=>"bike4.jpg"],
  103 => ["name"=>"BMW S1000RR (2020)", "price"=>857, "img"=>"bike3.jpg"],
  250 => ["name"=>"BMW 7 Series (2022)", "price"=>2780, "img"=>"car1.jpg"],
  261 => ["name"=>"Lamborghini Huracán (2021)", "price"=>5500, "img"=>"car5.jpg"],
  278 => ["name"=>"Hennessey Venom F5 (2020)", "price"=>25000, "img"=>"car3.jpg"]
];

if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  if (isset($items[$id])) {
    $_SESSION['cart'][] = [
      "id"    => $id,
      "name"  => $items[$id]["name"],
      "price" => $items[$id]["price"],
      "img"   => $items[$id]["img"]
    ];
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Cart - Luxury Rentals</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>

<h2>Your Cart</h2>
<div class="cart-box">

<?php
if (empty($_SESSION['cart'])) {
  echo "<p>Cart is empty!</p>";
} else {
  foreach($_SESSION['cart'] as $item){
    echo "<div class='card'>
            <img src='../images/{$item['img']}' width='150'>
            <p><strong>{$item['name']}</strong></p>
            <p>RM {$item['price']} / day</p>
          </div><hr>";
  }
  echo "<a href='checkout.php' class='btn'>Proceed to Checkout</a>";
}
?>
    <a href="clear_cart.php" class="btn">Clear Cart</a>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include("../footer.php"); ?>
</body>
</html>
