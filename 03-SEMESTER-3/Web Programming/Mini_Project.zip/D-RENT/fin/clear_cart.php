<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Remove only cart data (keep user logged in)
unset($_SESSION['cart']);

// Optional: also remove receipt snapshot if you want
unset($_SESSION['receipt_snapshot']);
unset($_SESSION['receipt_days']);
unset($_SESSION['receipt_fullname']);

// Redirect back to cart page
header("Location: cart.php");
exit;
