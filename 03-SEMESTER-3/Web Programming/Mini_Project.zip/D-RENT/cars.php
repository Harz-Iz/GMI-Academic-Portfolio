<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// if no active login, redirect to login page
if (!isset($_SESSION['user'])) {
    header("Location: acc/login.php");
    exit;
}
?>

<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Supercars - Luxury Rentals</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Supercars</h2>
<div class="showcase">
<?php
$cars = [
  ["id"=>250, "name"=>"BMW 7 Series (2022)", "price"=>2780, "img"=>"car1.jpg"],
  ["id"=>261, "name"=>"Lamborghini Huracán (2021)", "price"=>5500, "img"=>"car5.jpg"],
  ["id"=>278, "name"=>"Hennessey Venom F5 (2020)", "price"=>25000, "img"=>"car3.jpg"],
];
foreach($cars as $c){
  echo "<div class='card'>
    <img src='images/{$c['img']}' alt='{$c['name']}'>
    <h3>{$c['name']}</h3>
    <p>RM {$c['price']} / day</p>
    <a href='fin/cart.php?id={$c['id']}&type=car' class='btn'>Rent Now</a>
  </div>";
}
?>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include("footer.php"); ?>
</body>
</html>
