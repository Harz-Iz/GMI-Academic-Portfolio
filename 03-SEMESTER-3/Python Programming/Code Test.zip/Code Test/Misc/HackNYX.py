#Clone Lekir's repo
git clone https://github.com/firdauskhairuddin/lekir-docker.git
cd lekir-docker