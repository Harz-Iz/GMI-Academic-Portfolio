"""def thing():
    print('Hello')
    print('Fun')

thing()
print('Zip')
thing()""" # < Arguments

"""def greet(lang):
    if lang == 'es':
        print ('Hola')
    elif lang == 'fr':
        print ('Bonjour')
    elif lang == 'my':
        print ('Salam')
    elif lang == 'jp':
        print ('Konnichiwa')
    elif lang == 'sw':
        print ("Kamek is groot")
    else:
        print ('Hello')

greet ('sw') """ # < Return Values Extended

"""def greet():
    return "Hello"

print (greet(), "Glenn")
print (greet(), "Sally")""" # < Return Function

"""Type Float
m=(float(99) / 100)
print (m)
print(type(m))

#Type Integer
i = 42
print(type(i))

#Type Float
f = float(i)
print (f)
print(type(f))
print (1 + 2 * float(3) / 4-5)""" # < Type Function

"""def greet(lang):
    if lang == 'es':
        return 'Hola'
    elif lang == 'fr':
        return 'Bonjour'
    else:
        return 'Hello'

print (greet('en'),'Glenn')
print (greet('es'),'Sally')
print (greet('fr'),'Michael')""" # < Arguments

"""def addtwo(a, b):
    added = a * b
    
    return added
x = addtwo(3,5)
print (x)""" # < Multiple Parameters (Multiplication)

"""def addtwo(a, b):
    added = a + b

    return added


x = addtwo(3, 5)
print(x)""" # < Multiple Parameters (Addition)

"""print('Entered Hours :')
hours = int(input())

if hours >= 40:
    rate = 10

else:
    rate = 5

Pay = hours * rate
print("Pay is:", Pay)""" # TASK 1

"""print("Enter first number:")
fnum = int(input())
print("Enter second number:")
snum = int(input())

def add():
    sum = fnum + snum
    print("The sum of ",fnum,"and ",snum,"is ",sum)
def minus():
    min = fnum - snum
    print("The min of ",fnum,"and ",snum,"is ",min)
def mult():
    multi = fnum * snum
    print("The multiplication of ",fnum,"and ",snum,"is ",multi)
def devi():
    dev = fnum / snum
    print("The division of ",fnum,"and ",snum,"is ",dev)

#Function Calling
add()
minus()
mult()
devi()""" # TASK 4

def show_employee():
    emp_name_input = input("Enter your name:")
    if emp_name_input == "":
        emp_name = "Fulan bin Fulan"
    else:
        emp_name = emp_name_input

    emp_sal_input = input("Enter your salary:")
    if emp_sal_input == "":
        emp_sal = 9000
    else:
        emp_sal = int(emp_sal_input)

    print("Employee's Name:", emp_name)
    print("Employee's Salary:", emp_sal)

show_employee() # TASK 8



