# Shopping list program

shopping_list = []

print("Enter your shopping list items (type 'done' when finished):")

while True:
    item = input("Item: ")
    if item.lower() == 'done':
        break
    elif item.strip() == "":
        print("You entered nothing. Try again.")
        continue
    else:
        shopping_list.append(item)

# Display the full shopping list
print("\nYour shopping list:")
print(", ".join(shopping_list))