# Blood Donor Management Program

donors = []  # List to store donor information

def display_menu():
    print("\n===== BLOOD DONOR MANAGEMENT SYSTEM =====")
    print("1. Add Donor")
    print("2. Search Donors by Blood Type")
    print("3. Exit")
    print("=========================================")

while True:
    display_menu()
    try:
        option = int(input("Enter option (1-3): "))
    except ValueError:
        print("Invalid input. Please enter a number between 1 and 3.")
        continue

    if option == 1:
        print("\n--- Add Donor ---")
        name = input("Enter donor's name: ")
        ic = input("Enter donor's IC number: ")
        age = input("Enter donor's age: ")
        gender = input("Enter donor's gender (Male/Female): ").capitalize()
        state = input("Enter donor's state: ").capitalize()
        blood_type = input("Enter donor's blood type: ").upper()

        donor = {
            "Name": name,
            "IC": ic,
            "Age": age,
            "Gender": gender,
            "State": state,
            "BloodType": blood_type
        }
        donors.append(donor)
        print("Donor added successfully!")

    elif option == 2:
        print("\n--- Search Donors ---")
        chosen_blood_type = input("Enter blood type to search: ").upper()
        filtered_donors = [d for d in donors if d["BloodType"] == chosen_blood_type]

        if not filtered_donors:
            print(f"No donors found with blood type {chosen_blood_type}.")
            continue

        print(f"\nDonors with blood type {chosen_blood_type}:")
        for donor in filtered_donors:
            print(donor)

        filter_method = input("Filter by (Gender/State): ").capitalize()

        if filter_method == "Gender":
            gender_filter = input("Enter gender (Male/Female): ").capitalize()
            result = [d for d in filtered_donors if d["Gender"] == gender_filter]
            print("\nFiltered Donors by Gender:")
            for donor in result:
                print(donor)

        elif filter_method == "State":
            state_filter = input("Enter state: ").capitalize()
            result = [d for d in filtered_donors if d["State"] == state_filter]
            print("\nFiltered Donors by State:")
            for donor in result:
                print(donor)

        else:
            print("Invalid filter method.")

    elif option == 3:
        print("Exiting Program...")
        break

    else:
        print("Invalid Option. Please select between 1 and 3.")
