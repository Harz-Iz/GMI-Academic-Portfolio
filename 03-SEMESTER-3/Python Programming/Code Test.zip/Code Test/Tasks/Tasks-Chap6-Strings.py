"""word = 'pneumonoultramicroscopicsilicovolcanoconiosis' #Real Lung Disease Btw 🤓
count = 0
for letter in word :
    if letter == 'o' :
       count = count + 1
print (count)"""

word = "pneumonoultramicroscopicsilicovolcanoconiosis"
print("Word:", word)
print("Bapak ah, ada", len(word), "letters! 🤯")

#Cari A
print("\nFirst 'a' found at index:", word.find("a"))

#Cari Subtring, cth Volcano
print("Substring 'volcano' found at index:", word.find("volcano"))

#Cari benda huruf yg tkde dlm word
print("Searching for 'z'... Result:", word.find("z"))  # returns -1

#Cari A tapi start dari index, cth 10
print("Searching for 'a' starting from index 10:", word.find("a", 10))

#Cari in between
print("Searching for 'a' between index 12 until 30:", word.find("a", 12, 30))

"""#===================================================================================================#
#Dan Punya str.replace
x = "pneumonoultramicroscopicsilicovolcanoconiosis"

print("\nOriginal word:", x)

#replace word
x = "pneumonoultramicroscopicsilicovolcanoconiosis"

print("\nOriginal word:", x)

#replace word
print("\nReplace 'micro' with 'mega': ")
print(x.replace("micro", "mega"))

#replace letter
print("\nReplace 7 of 'o' with 'A': ")
print(x.replace("o", "A", 7))"""
