
# Input from string and convert both into float
hours = float(input("Enter hour: "))

Normal_rate = 5
Overtime_rate = 10

if hours > 40 :
    rate = Overtime_rate
else :
    rate = Normal_rate
Pay = hours * rate

#Calculation hour multiplied by rate
print("Pay:", Pay)
