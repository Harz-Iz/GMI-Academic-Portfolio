# # 1. Create the dictionary with the specified key-value pairs
# data_dict = {
#     'JMV': 6767,
#     'RF': 478,
#     'ABC': 123
# }
#
# # 2. Use the .items() method to get the key-value pairs
# # 3. Use the list() function to convert the result into a list of tuples
# list_of_tuples = list(data_dict.items())
#
# # 4. Print the final list
# print(list_of_tuples)

#########################################################################

# # 1. Create the two tuples from your input
# # (The comma at the end of 'Eisley', in your image implies they are tuples)
# tuple1 = ('All American Rejects', 'My Chemical Romance')
# tuple2 = ('Mayday Parade', 'Eisley')
#
# # 2. Compare the two tuples
# # Python compares tuples element by element, in order.
# # It checks: Is 'All American Rejects' < 'Mayday Parade'?
# # Alphabetically, 'A' comes before 'M', so this is True.
# # The comparison stops, and the whole expression is True.
# result = tuple1 < tuple2
#
# # 3. Print the output
# print(result)
###################################################################

# Create the dictionary
data_dict = {
    'JMV': 6767,
    'RF': 478,
    'ABC': 123
}

# Use list() and .items() to get the list of tuples
list_of_tuples = list(data_dict.items())

# Print the result
print(list_of_tuples)

####################################################################

# # #Tuples & Dictionaries
# # d = dict()
# #
# # d['Avdol'] = 2
# # d['Harz'] = 4
# # d['Ah Meng'] = 6
# # d['Bang Aji'] = 8
# # d['Ijat Ridwan'] = 67
# #
# # #Loop through the items and print them
# # print("--- Looping through all items ---")
# # for (k, v) in d.items():
# #     print(k, v)
# #
# # print("\n--- Final list of tuples ---")
# # tups = list(d.items())
# # print(tups)
#
# ######################################################################
#
# print((0, 1, 2) < (5, 1, 2))

########################################################################

# # 1. Create the dictionary with the specified key-value pairs
# data_dict = {
#     'JMV': 6767,
#     'RF': 478,
#     'ABC': 123
# }
#
# # 2. Use the .items() method to get the (key, value) pairs
# #    and use list() to convert them into a list.
# list_of_tuples = list(data_dict.items())
#
# # 3. Print the final list
# print(list_of_tuples)

