# Step 1: Create a main dictionary called 'friends'
friends = {
    "Aiman": {"age": 20, "phone": "012-3456789", "city": "Kuala Lumpur"},
    "Hafiz": {"age": 21, "phone": "013-9876543", "city": "Johor Bahru"},
    "Sara": {"age": 19, "phone": "014-2233445", "city": "Penang"}
}

# Step 3: Add one more friend after creation
friends["Farah"] = {"age": 22, "phone": "016-5566778", "city": "Ipoh"}

# Step 4: Update one of your friend’s details (for example, change city)
friends["Hafiz"]["city"] = "Melaka"

# Step 5: Display the required information
print("All friends' names:")
for name in friends.keys():
    print("-", name)

print("\nDetails of one specific friend (Sara):")
print(friends["Sara"])

print("\nTotal number of friends in your directory:", len(friends))
