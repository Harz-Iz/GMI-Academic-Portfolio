#!/usr/bin/env python3
"""
Enhanced Network Discovery Scanner with Creative Features
- Auto-detects local network or manual range
- **NEW**: User can select subnet size (/24, /16, etc.) for auto-detect
- Real-time interactive display
- Service detection & banner grabbing
- HTML report generation
- Vulnerability assessment
- Network topology mapping
- Multi-format exports
"""

import socket
import ipaddress
import concurrent.futures
import csv
import platform
import subprocess
import re
import json
import argparse
from datetime import datetime, timezone
from typing import List, Dict, Any

# ========== NEW HELPER FUNCTION ==========

def get_local_ip():
    """Better way to get a likely non-loopback local IP (no packets sent)."""
    try:
        # Attempt a UDP "connect" to an external IP; doesn't send traffic but yields a suitable local IP
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        # fallback
        try:
            name = socket.gethostname()
            ip = socket.gethostbyname(name)
            if ip.startswith("127."):
                # fallback to checking all interfaces
                for info in socket.getaddrinfo(name, None):
                    candidate = info[4][0]
                    if not candidate.startswith("127."):
                        return candidate
            return ip
        except Exception:
            return "127.0.0.1"


# ========== ENHANCED FEATURES ==========

class NetworkScanner:
    def __init__(self):
        self.scan_results = []
        self.discovered_services = {}

    # --- MODIFIED METHOD ---
    # Auto-detect local network
    def auto_detect_network(self):
        """Auto-detect the local network range with user-defined subnet size."""
        try:
            # Use the robust get_local_ip helper
            local_ip = get_local_ip()
            if local_ip.startswith("127."):
                print("[ERROR] Could not reliably detect a non-loopback local IP. Please enter a range manually.")
                return []

            # Ask for subnet size, with /24 as default
            subnet_input = input("Enter subnet size (e.g., /24, /16, /27). Press Enter for default [/24]: ").strip()
            if subnet_input == "":
                subnet_cidr = "24"
            else:
                # Basic validation, remove the "/" if present
                subnet_cidr = subnet_input.replace('/', '').strip()

            try:
                # Use strict=False to create the network object from the IP and prefix
                network = ipaddress.ip_network(f"{local_ip}/{subnet_cidr}", strict=False)
            except ValueError as e:
                print(f"[ERROR] Invalid subnet size: {e}. Please enter a valid CIDR prefix (e.g., 8-32).")
                return []

            hosts = list(network.hosts())
            if not hosts:
                # This might happen with a /31 or /32
                print(f"[ERROR] Network {network} has no usable host IPs. Please enter a range manually.")
                return []

            print(f"\n[INFO] Detected Network: {network}")
            print(f"[INFO] Local IP: {local_ip}")
            print(f"[INFO] Scanning Range: {hosts[0]} - {hosts[-1]} ({len(hosts)} hosts)")
            return [str(ip) for ip in hosts]

        except Exception as e:
            print(f"[ERROR] Auto-detection failed: {e}")
            return []
    # --- END MODIFIED METHOD ---

    # Ping host (cross-platform)
    def ping_host(self, ip: str, timeout: float = 1.0):
        """Ping a host to check if it's alive"""
        system = platform.system().lower()
        if system == 'windows':
            cmd = ['ping', '-n', '1', '-w', str(int(timeout * 1000)), ip]
        else:
            cmd = ['ping', '-c', '1', '-W', str(max(1, int(round(timeout)))), ip]

        try:
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 universal_newlines=True, timeout=timeout + 1)
            out = res.stdout + res.stderr
            is_up = res.returncode == 0
            rtt = None
            m = re.search(r'time[=<]\s*([0-9.]+)\s*ms', out)
            if m:
                rtt = float(m.group(1))
            return is_up, rtt
        except Exception:
            return False, None

    # Enhanced TCP port scanning with service detection
    def probe_port(self, ip: str, port: int, timeout: float = 0.5) -> bool:
        """Probe TCP port and detect service"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                result = s.connect_ex((ip, port))
                return result == 0
        except Exception:
            return False

    def detect_service(self, ip: str, port: int, timeout: float = 2.0):
        """Enhanced service detection with banner grabbing"""
        service_map = {
            21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
            53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP",
            443: "HTTPS", 445: "SMB", 8080: "HTTP-Alt",
            3306: "MySQL", 5432: "PostgreSQL", 3389: "RDP"
        }

        default_service = service_map.get(port, f"Unknown ({port})")

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                s.connect((ip, port))

                # Attempt banner grabbing based on service
                if port in [21]:  # FTP
                    s.send(b"\r\n")
                    banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
                    return f"FTP: {banner}" if banner else "FTP"

                elif port in [22]:  # SSH
                    banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
                    return f"SSH: {banner}" if banner else "SSH"

                elif port in [80, 443, 8080]:  # HTTP/HTTPS
                    s.send(b"HEAD / HTTP/1.0\r\n\r\n")
                    banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
                    if 'Server:' in banner:
                        server_info = [line for line in banner.split('\n') if 'Server:' in line]
                        if server_info:
                            return f"Web: {server_info[0][8:].strip()}"
                    return "Web Server"

                elif port in [25]:  # SMTP
                    banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
                    return f"SMTP: {banner}" if banner else "SMTP"

        except Exception as e:
            pass

        return default_service

    # Reverse DNS lookup
    def reverse_dns(self, ip: str):
        """Resolve hostname from IP address"""
        try:
            name = socket.gethostbyaddr(ip)[0]
            return name
        except Exception:
            try:
                fqdn = socket.getfqdn(ip)
                if fqdn != ip:
                    return fqdn
            except Exception:
                pass
        return "Unknown"

    # OS detection via TTL
    def parse_ttl_from_ping(self, ip: str, timeout: float = 1.0):
        """Extract TTL from ping response for OS detection"""
        system = platform.system().lower()
        if system == 'windows':
            cmd = ['ping', '-n', '1', '-w', str(int(timeout * 1000)), ip]
        else:
            cmd = ['ping', '-c', '1', '-W', str(max(1, int(round(timeout)))), ip]
        try:
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 universal_newlines=True, timeout=timeout + 1)
            out = res.stdout + res.stderr
            m = re.search(r'[Tt][Tt][Ll]?=\s*([0-9]+)', out)
            if m:
                return int(m.group(1))
        except Exception:
            pass
        return None

    def guess_os(self, ttl: int):
        """Guess operating system based on TTL value"""
        if ttl is None:
            return "Unknown"
        if ttl >= 200:
            return "Network Device/Router"
        if 120 <= ttl <= 140:
            return "Windows"
        if 50 <= ttl <= 80:
            return "Linux/Unix"
        return "Unknown"

    # Vulnerability assessment
    def quick_vuln_check(self, ip: str, open_ports: list):
        """Basic security assessment for common issues"""
        warnings = []

        risky_services = {
            21: "FTP - Plaintext credentials transmission",
            23: "Telnet - Insecure protocol",
            135: "RPC - Potential vulnerability",
            139: "NetBIOS - SMB exposure",
            445: "SMB - Potential EternalBlue vulnerability",
            3389: "RDP - Remote Desktop exposure"
        }

        for port in open_ports:
            if port in risky_services:
                warnings.append(f"Port {port}: {risky_services[port]}")

        # Web service security note
        web_ports = [80, 443, 8080, 8000, 3000]
        if any(port in web_ports for port in open_ports):
            warnings.append("Web service detected - check for security headers")

        return warnings

    # Enhanced scanning with service detection
    def scan_one(self, ip: str, ports, ping_timeout: float, port_timeout: float):
        """Enhanced single host scanning with service detection"""
        result = {
            'ip': ip,
            'up': False,
            'rtt_ms': None,
            'ttl': None,
            'os_guess': None,
            'reverse_dns': None,
            'open_ports': [],
            'services': {},
            'vulnerability_warnings': []
        }

        is_up, rtt = self.ping_host(ip, timeout=ping_timeout)
        result['up'] = is_up
        result['rtt_ms'] = rtt

        if is_up:
            ttl = self.parse_ttl_from_ping(ip, timeout=ping_timeout)
            result['ttl'] = ttl
            result['os_guess'] = self.guess_os(ttl)
            result['reverse_dns'] = self.reverse_dns(ip)

            # Scan ports and detect services
            for port in ports:
                if self.probe_port(ip, port, timeout=port_timeout):
                    result['open_ports'].append(port)
                    service_info = self.detect_service(ip, port)
                    result['services'][port] = service_info

            # Vulnerability assessment
            result['vulnerability_warnings'] = self.quick_vuln_check(ip, result['open_ports'])

        return result

    # Multi-format export
    def save_to_csv(self, results, filename):
        """Save results to CSV format"""
        fields = ['ip', 'up', 'rtt_ms', 'ttl', 'os_guess', 'reverse_dns', 'open_ports', 'services',
                  'vulnerability_warnings']
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for r in results:
                row = {k: r.get(k) for k in fields}
                row['open_ports'] = ','.join(map(str, r['open_ports']))
                row['services'] = json.dumps(r['services'])
                row['vulnerability_warnings'] = '; '.join(r['vulnerability_warnings'])
                writer.writerow(row)

    def save_to_json(self, results, filename):
        """Save results to JSON format"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, default=str)

    def generate_html_report(self, results, filename):
        """Generate interactive HTML report with proper encoding"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # HTML template without emojis to avoid encoding issues
        html_template = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Network Scan Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; text-align: center; }}
        .summary {{ background: #e8f4fd; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #4CAF50; color: white; }}
        tr:hover {{ background-color: #f5f5f5; }}
        .online {{ color: green; font-weight: bold; }}
        .offline {{ color: red; }}
        .warning {{ color: orange; font-weight: bold; }}
        .service-badge {{ background: #2196F3; color: white; padding: 2px 6px; border-radius: 3px; font-size: 0.8em; margin: 2px; display: inline-block; }}
        .status-online {{ color: green; }}
        .status-offline {{ color: red; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Network Scan Report</h1>
        <div class="summary">
            <h3>Scan Summary</h3>
            <p><strong>Generated:</strong> {timestamp}</p>
            <p><strong>Total Hosts Scanned:</strong> {len(results)}</p>
            <p><strong>Online Hosts:</strong> {sum(1 for r in results if r['up'])}</p>
        </div>
        <table>
            <thead>
                <tr>
                    <th>IP Address</th>
                    <th>Status</th>
                    <th>Hostname</th>
                    <th>OS Guess</th>
                    <th>Open Ports & Services</th>
                    <th>Security Warnings</th>
                    <th>Response Time</th>
                </tr>
            </thead>
            <tbody>"""

        # Generate table rows
        for host in results:
            status_class = "status-online" if host['up'] else "status-offline"
            status_text = "ONLINE" if host['up'] else "OFFLINE"
            status_symbol = "●" if host['up'] else "○"

            # Format services
            services_html = ""
            if host['services']:
                for port, service in host['services'].items():
                    services_html += f'<span class="service-badge">{port}: {service}</span>'
            else:
                services_html = "None"

            # Format warnings
            warnings_html = "<br>".join(host['vulnerability_warnings']) if host['vulnerability_warnings'] else "None"

            html_template += f"""
                <tr>
                    <td>{host['ip']}</td>
                    <td class="{status_class}">{status_symbol} {status_text}</td>
                    <td>{host['reverse_dns']}</td>
                    <td>{host['os_guess']}</td>
                    <td>{services_html}</td>
                    <td class="warning">{warnings_html}</td>
                    <td>{host['rtt_ms'] or 'N/A'} ms</td>
                </tr>"""

        html_template += """
            </tbody>
        </table>
    </div>
</body>
</html>"""

        # Write with proper encoding
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html_template)
        print(f"[INFO] HTML report generated: {filename}")

    # Network topology mapping
    def build_topology(self, results):
        """Build simple network topology"""
        topology = {
            "local_hosts": [],
            "network_devices": [],
            "servers": []
        }

        for host in results:
            if host['up']:
                # Classify based on open ports and TTL
                if host['ttl'] and host['ttl'] >= 200:
                    topology["network_devices"].append({
                        "ip": host['ip'],
                        "hostname": host['reverse_dns'],
                        "type": "Router/Gateway"
                    })
                elif any(port in [80, 443, 22, 21, 25] for port in host['open_ports']):
                    topology["servers"].append({
                        "ip": host['ip'],
                        "hostname": host['reverse_dns'],
                        "services": host['services']
                    })
                else:
                    topology["local_hosts"].append({
                        "ip": host['ip'],
                        "hostname": host['reverse_dns'],
                        "os": host['os_guess']
                    })

        return topology

    # Display topology
    def display_topology(self, topology):
        """Display network topology in a readable format"""
        print("\n" + "=" * 50)
        print("NETWORK TOPOLOGY MAP")
        print("=" * 50)

        print("\nNETWORK DEVICES:")
        for device in topology["network_devices"]:
            print(f"  * {device['ip']} ({device['hostname']}) - {device['type']}")

        print("\nSERVERS:")
        for server in topology["servers"]:
            services = ', '.join([f"{port}({svc})" for port, svc in server['services'].items()])
            print(f"  * {server['ip']} ({server['hostname']}) - Services: {services}")

        print("\nWORKSTATIONS:")
        for host in topology["local_hosts"]:
            print(f"  * {host['ip']} ({host['hostname']}) - OS: {host['os']}")

        print("\n" + "=" * 50)

    # Scan summary with enhanced statistics
    def show_summary(self, results, elapsed, filename):
        """Display comprehensive scan summary"""
        up_count = sum(1 for r in results if r['up'])
        open_ports_total = sum(len(r['open_ports']) for r in results)
        total_warnings = sum(len(r['vulnerability_warnings']) for r in results)

        # Service statistics
        services_found = {}
        for host in results:
            for port, service in host['services'].items():
                services_found[service] = services_found.get(service, 0) + 1

        print("\n" + "=" * 60)
        print("ENHANCED SCAN SUMMARY")
        print("=" * 60)
        print(f"Total IPs Scanned     : {len(results)}")
        print(f"Online Hosts          : {up_count}")
        print(f"Open Ports Found      : {open_ports_total}")
        print(f"Security Warnings     : {total_warnings}")
        print(f"Scan Duration         : {elapsed:.1f} seconds")
        print(f"Results File          : {filename}")

        if services_found:
            print(f"\nServices Discovered:")
            for service, count in services_found.items():
                print(f"  * {service}: {count} hosts")

        print("=" * 60)


# Main execution function
def main():
    scanner = NetworkScanner()

    print("ENHANCED NETWORK SCANNER")
    print("=" * 50)

    # Network range selection
    choice = input("Auto-detect local network range? (y/n): ").lower().strip()

    if choice == 'y':
        ip_list = scanner.auto_detect_network()
        if not ip_list:
            print("[ERROR] Auto-detection failed. Exiting.")
            return
    else:
        try:
            start_ip = input("Enter starting IP: ").strip()
            end_ip = input("Enter ending IP: ").strip()
            start = ipaddress.IPv4Address(start_ip)
            end = ipaddress.IPv4Address(end_ip)
            if int(end) < int(start):
                print("[ERROR] Ending IP must be >= starting IP.")
                return
            ip_list = [str(ipaddress.IPv4Address(i)) for i in range(int(start), int(end) + 1)]
            print(f"[INFO] Manual range: {ip_list[0]} - {ip_list[-1]}")
        except Exception as e:
            print(f"[ERROR] Invalid IP range: {e}")
            return

    # Enhanced port selection
    default_ports = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 8080, 3389, 3306]
    port_choice = input(f"Use default ports {default_ports}? (y/n): ").lower().strip()

    if port_choice == 'y' or port_choice == '':
        ports = default_ports
    else:
        try:
            custom_ports = input("Enter ports (comma-separated): ").strip()
            ports = [int(port.strip()) for port in custom_ports.split(',') if port.strip()]
            if not ports:
                raise ValueError("No valid ports entered.")
        except Exception as e:
            print(f"[ERROR] Invalid ports, using defaults: {e}")
            ports = default_ports

    print(f"\n[INFO] Scanning {len(ip_list)} hosts on ports {ports}...")
    print("[INFO] This may take a few minutes...\n")

    start_time = datetime.now(timezone.utc)
    results = []
    online_count = 0

    # Multi-threaded scanning
    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(scanner.scan_one, ip, ports, 1.0, 0.5): ip for ip in ip_list}

        for future in concurrent.futures.as_completed(futures):
            ip = futures[future]
            try:
                result = future.result()
                results.append(result)

                # Display online hosts in real-time
                if result['up']:
                    online_count += 1
                    services_str = ', '.join([f"{port}({svc})" for port, svc in result['services'].items()])
                    warnings_str = f" [WARNINGS: {len(result['vulnerability_warnings'])}]" if result[
                        'vulnerability_warnings'] else ""

                    print(f"[ONLINE] {result['ip']} | {result['reverse_dns']} | "
                          f"OS: {result['os_guess']} | "
                          f"Ports: {services_str or 'None'}{warnings_str}")

            except Exception as e:
                print(f"[ERROR] Scanning {ip}: {e}")

    elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()

    # Generate outputs
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    base_filename = f"network_scan_{timestamp}"

    # Sort results by IP for cleaner reports
    results.sort(key=lambda x: ipaddress.ip_address(x['ip']))

    # Save to multiple formats
    scanner.save_to_csv(results, f"{base_filename}.csv")
    scanner.save_to_json(results, f"{base_filename}.json")
    scanner.generate_html_report(results, f"{base_filename}.html")

    # Display results
    scanner.show_summary(results, elapsed, f"{base_filename}.csv")

    # Show topology
    topology = scanner.build_topology(results)
    scanner.display_topology(topology)

    print(f"\n[SUCCESS] Scan completed! Check the generated files:")
    print(f"   CSV: {base_filename}.csv")
    print(f"   JSON: {base_filename}.json")
    print(f"   HTML: {base_filename}.html")


if __name__ == '__main__':
    main()