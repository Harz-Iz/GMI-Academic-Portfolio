#!/usr/bin/env python3
"""
Enhanced Network Discovery Scanner (console shows only online hosts)
- Auto-detects local network (robust method) or accepts a manual range
- **NEW**: User can select subnet size (/24, /16, etc.) for auto-detect
- Scans with ping + TCP probes (socket.connect_ex)
- Resolves reverse DNS for online hosts (returns None if not resolvable)
- Saves full results to CSV
- Console output displays only hosts that are UP (online)
- Added user inputs for ports, timeouts, concurrency
"""

import socket
import ipaddress
import concurrent.futures
import csv
import platform
import subprocess
import re
from datetime import datetime, timezone

# --------------------- Utilities / Fixes ---------------------

def get_local_ip():
    """Better way to get a likely non-loopback local IP (no packets sent)."""
    try:
        # Attempt a UDP "connect" to an external IP; doesn't send traffic but yields a suitable local IP
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        # fallback
        try:
            name = socket.gethostname()
            ip = socket.gethostbyname(name)
            if ip.startswith("127."):
                # fallback to checking all interfaces
                for info in socket.getaddrinfo(name, None):
                    candidate = info[4][0]
                    if not candidate.startswith("127."):
                        return candidate
            return ip
        except Exception:
            return "127.0.0.1"

# Auto-detect local network (robust)
def auto_detect_network():
    local_ip = get_local_ip()
    # If the IP looks like loopback, warn user
    if local_ip.startswith("127."):
        print("⚠️  Could not reliably detect a non-loopback local IP. Please enter a range manually.")
        return None

    # --- MODIFIED SECTION ---
    # Ask for subnet size, with /24 as default
    subnet_input = input("Enter subnet size (e.g., /24, /16, /27). Press Enter for default [/24]: ").strip()
    if subnet_input == "":
        subnet_cidr = "24"
    else:
        # Basic validation, remove the "/" if present
        subnet_cidr = subnet_input.replace('/', '').strip()

    try:
        # Use strict=False to create the network object from the IP and prefix
        network = ipaddress.ip_network(f"{local_ip}/{subnet_cidr}", strict=False)
    except ValueError as e:
        print(f"⚠️  Invalid subnet size: {e}. Please enter a valid CIDR prefix (e.g., 8-32).")
        return None
    # --- END MODIFIED SECTION ---

    hosts = list(network.hosts())
    if not hosts:
        # This might happen with a /31 or /32
        print(f"⚠️  Network {network} has no usable host IPs. Please enter a range manually.")
        return None

    print(f"\n🌐 Detected Network: {network}")
    print(f"📡 Local IP: {local_ip}")
    # Added host count as a sanity check for the user
    print(f"🔍 Scanning Range: {hosts[0]} - {hosts[-1]} ({len(hosts)} hosts)")
    return [str(ip) for ip in hosts]

# Parse user port input like: 22,80,8000-8010
def parse_ports(ports_str):
    if not ports_str:
        return []
    ports = set()
    for part in ports_str.split(','):
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            try:
                a, b = part.split('-', 1)
                a, b = int(a), int(b)
                for p in range(max(1, a), min(65535, b) + 1):
                    ports.add(p)
            except Exception:
                continue
        else:
            try:
                p = int(part)
                if 1 <= p <= 65535:
                    ports.add(p)
            except Exception:
                continue
    return sorted(ports)

# Ping host (cross-platform). Simpler approach: use basic flags and rely on subprocess timeout.
def ping_host(ip: str, timeout: float = 1.0):
    system = platform.system().lower()
    if system == 'windows':
        # -n 1 (count), -w milliseconds for timeout
        cmd = ['ping', '-n', '1', '-w', str(int(timeout * 1000)), ip]
        # on Windows, subprocess timeout still applies
    else:
        # use single ping and rely on subprocess timeout to bound total time
        # this avoids platform-specific -W/-t inconsistencies (Linux vs macOS)
        cmd = ['ping', '-c', '1', ip]

    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             universal_newlines=True, timeout=timeout + 1)
        out = (res.stdout or "") + (res.stderr or "")
        is_up = (res.returncode == 0)
        rtt = None
        # parse round-trip time if present (Linux/macOS/Windows formats vary)
        m = re.search(r'time[=<]\s*([0-9.]+)\s*ms', out, re.IGNORECASE)
        if m:
            try:
                rtt = float(m.group(1))
            except Exception:
                rtt = None
        return is_up, rtt
    except subprocess.TimeoutExpired:
        return False, None
    except Exception:
        return False, None

# Probe TCP port using connect_ex
def probe_port(ip: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            result = s.connect_ex((ip, port))
            return result == 0
    except Exception:
        return False

# Reverse DNS - return None when unknown (so console shows '-' instead of "Unknown")
def reverse_dns(ip: str):
    try:
        name = socket.gethostbyaddr(ip)[0]
        return name
    except Exception:
        try:
            fqdn = socket.getfqdn(ip)
            if fqdn and fqdn != ip:
                return fqdn
        except Exception:
            pass
    return None

# TTL parsing / OS guess
def parse_ttl_from_ping(ip: str, timeout: float = 1.0):
    system = platform.system().lower()
    if system == 'windows':
        cmd = ['ping', '-n', '1', '-w', str(int(timeout * 1000)), ip]
    else:
        cmd = ['ping', '-c', '1', ip]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             universal_newlines=True, timeout=timeout + 1)
        out = (res.stdout or "") + (res.stderr or "")
        # generic ttl capture: look for ttl=number (case-insensitive)
        m = re.search(r'\bttl[=:\s]+(\d+)\b', out, re.IGNORECASE)
        if m:
            try:
                return int(m.group(1))
            except Exception:
                return None
    except Exception:
        pass
    return None

def guess_os(ttl: int):
    if ttl is None:
        return None
    # heuristics (loose)
    if ttl >= 200:
        return "Network Device/Router"
    if 120 <= ttl <= 140:
        return "Windows"
    if 50 <= ttl <= 80:
        return "Linux/Unix"
    return "Unknown"

# --------------------- Scanning logic ---------------------

def scan_one(ip: str, ports, ping_timeout: float, port_timeout: float):
    result = {
        'ip': ip,
        'up': False,
        'rtt_ms': None,
        'ttl': None,
        'os_guess': None,
        'reverse_dns': None,
        'open_ports': []
    }

    is_up, rtt = ping_host(ip, timeout=ping_timeout)
    result['up'] = is_up
    result['rtt_ms'] = rtt

    if is_up:
        ttl = parse_ttl_from_ping(ip, timeout=ping_timeout)
        result['ttl'] = ttl
        result['os_guess'] = guess_os(ttl)
        result['reverse_dns'] = reverse_dns(ip)

        for p in ports:
            if probe_port(ip, p, timeout=port_timeout):
                result['open_ports'].append(p)

    return result

# Save to CSV
def save_to_csv(results, filename):
    fields = ['ip', 'up', 'rtt_ms', 'ttl', 'os_guess', 'reverse_dns', 'open_ports']
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            row = {k: r.get(k) for k in fields}
            row['open_ports'] = ','.join(map(str, r['open_ports']))
            # ensure None => empty string in CSV
            for k, v in row.items():
                if v is None:
                    row[k] = ''
            writer.writerow(row)

# Summary
def show_summary(results, elapsed, filename):
    up_count = sum(1 for r in results if r['up'])
    open_ports = sum(len(r['open_ports']) for r in results)
    print("\n========= Scan Summary =========")
    print(f"Total IPs Scanned : {len(results)}")
    print(f"Online Hosts      : {up_count}")
    print(f"Open Ports Found  : {open_ports}")
    print(f"Duration          : {elapsed:.1f} seconds")
    print(f"Results saved to  : {filename}")
    print("================================\n")

# --------------------- Main (interactive) ---------------------

def main():
    print("=== Enhanced Network Scanner (displaying only online hosts) ===")
    while True:
        choice = input("Auto-detect local network range? (y/n): ").strip().lower()
        if choice in ('y','n'):
            break

    if choice == 'y':
        ip_list = auto_detect_network()
        if ip_list is None:
            # fallback to manual entry if auto-detect failed
            choice = 'n'
            # Need to re-trigger manual entry logic
            print("Auto-detect failed. Please enter a range manually.")

    if choice == 'n':
        start_ip = input("Enter the starting IP address: ").strip()
        end_ip = input("Enter the ending IP address: ").strip()
        try:
            start = ipaddress.IPv4Address(start_ip)
            end = ipaddress.IPv4Address(end_ip)
            if int(end) < int(start):
                print("Ending IP must be >= starting IP.")
                return
            ip_list = [str(ipaddress.IPv4Address(i)) for i in range(int(start), int(end) + 1)]
        except Exception as e:
            print(f"Invalid IP range: {e}")
            return

    # ports input (default set if blank)
    default_ports = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 8080]
    ports_input = input(f"Ports to scan (comma/range). Press Enter for default {default_ports}: ").strip()
    if ports_input == "":
        ports = default_ports
    else:
        ports = parse_ports(ports_input)
        if not ports:
            print("No valid ports parsed; using defaults.")
            ports = default_ports

    # concurrency & timeouts
    try:
        max_workers = int(input("Max concurrent threads (default 100): ").strip() or "100")
    except Exception:
        max_workers = 100

    try:
        ping_timeout = float(input("Ping timeout in seconds (default 1.0): ").strip() or "1.0")
    except Exception:
        ping_timeout = 1.0

    try:
        port_timeout = float(input("Port probe timeout in seconds (default 0.5): ").strip() or "0.5")
    except Exception:
        port_timeout = 0.5

    print(f"\n🔧 Scanning {len(ip_list)} IPs on ports {ports} with {max_workers} threads...\n")

    start_time = datetime.now(timezone.utc)
    results = []
    online_count = 0

    # Multi-threaded scanning
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(scan_one, ip, ports, ping_timeout, port_timeout): ip for ip in ip_list}
        for fut in concurrent.futures.as_completed(futures):
            ip = futures[fut]
            try:
                res = fut.result()
                results.append(res)
                if res['up']:
                    online_count += 1
                    print(f"{res['ip']} -> 🟢 ONLINE | Ports: {res['open_ports'] or '-'} | Host: {res['reverse_dns'] or '-'} | OS: {res['os_guess'] or '-'}")
            except Exception as e:
                print(f"Error scanning {ip}: {e}")

    elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()
    filename = f"network_scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    save_to_csv(results, filename)
    show_summary(results, elapsed, filename)


if __name__ == '__main__':
    main()