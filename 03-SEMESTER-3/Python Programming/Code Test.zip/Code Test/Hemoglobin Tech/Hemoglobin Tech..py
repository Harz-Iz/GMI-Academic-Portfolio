donors = [
    {"name": "Ali Ahmad", "ic": "900101-10-1234", "age": 35, "gender": "Male", "state": "Selangor", "type": "A+"},
    {"name": "Siti Nur", "ic": "920202-14-5678", "age": 32, "gender": "Female", "state": "Johor", "type": "A-"},
    {"name": "Rahman Ismail", "ic": "880303-05-3456", "age": 37, "gender": "Male", "state": "Penang", "type": "B+"},
    {"name": "Fatimah Zain", "ic": "950404-07-6789", "age": 29, "gender": "Female", "state": "Perak", "type": "B-"},
    {"name": "Hafiz Abdullah", "ic": "870505-11-9876", "age": 38, "gender": "Male", "state": "Sabah", "type": "AB+"},
    {"name": "Aisyah Karim", "ic": "960606-08-1122", "age": 28, "gender": "Female", "state": "Sarawak", "type": "AB-"},
    {"name": "Faizal Rahim", "ic": "930707-06-2233", "age": 31, "gender": "Male", "state": "Kuala Lumpur", "type": "O+"},
    {"name": "Nurul Iman", "ic": "970808-12-3344", "age": 27, "gender": "Female", "state": "Malacca", "type": "O-"},
    {"name": "Daniel Tan", "ic": "890909-02-4455", "age": 36, "gender": "Male", "state": "Pahang", "type": "AB+"},
    {"name": "Mei Ling", "ic": "981010-16-5566", "age": 26, "gender": "Female", "state": "Negeri Sembilan", "type": "A+"}
]

states = {
    "1": "Johor",
    "2": "Malacca",
    "3": "Negeri Sembilan",
    "4": "Selangor",
    "5": "Perak",
    "6": "Kedah",
    "7": "Penang",
    "8": "Perlis",
    "9": "Kelantan",
    "10": "Terengganu",
    "11": "Pahang",
    "12": "Sabah",
    "13": "Sarawak",
    "14": "Kuala Lumpur",
    "15": "Putrajaya",
    "16": "Labuan"
}

b_types = {
    "1": "A+",
    "2": "A-",
    "3": "B+",
    "4": "B-",
    "5": "AB+",
    "6": "AB-",
    "7": "O+",
    "8": "O-"
}

def menu():
    print("\n---Hemoglobin Tech---")
    print("1. Register as new donor")
    print("2. Search Blood Type")
    print("3. Exit")
    op = input("Enter option (1-3): ")
    return op

def blood_t():
    while True:
        print("\nChoose blood type:")
        for x, y in b_types.items():
            print(f"{x}. {y}")
        ch = input("Enter your choice (1-8): ")
        if ch in b_types:
            return b_types[ch]
        else:
            print("Invalid choice. Please try again.")

def ch_gender():
    while True:
        gender = input("Enter your gender (m/f): ")
        if gender.lower() == "m":
            return "Male"
        elif gender.lower() == "f":
            return "Female"
        else:
            print("Invalid choice. Please enter m or f only")

def ch_state():
    while True:
        print("\nChoose state:")
        for x, y in states.items():
            print(f"{x}. {y}")
        ch = input("Enter your choice (1-16): ")
        if ch in states:
            return states[ch]
        else:
            print("Invalid choice. Please try again.")

def add():
    donor = {}
    donor["name"] = input("Enter your name: ")
    donor["ic"] = input("Enter your IC number: ")
    donor["age"] = int(input("Enter your age: "))
    donor["gender"] = ch_gender()
    donor["state"] = ch_state()
    donor["type"] = blood_t()
    donors.append(donor)
    print("Donor successfully added")

def print_donor(donor):
    print(f"Name: {donor['name']}, IC: {donor['ic']}, Age: {donor['age']}, "
          f"Gender: {donor['gender']}, State: {donor['state']}, Blood Type: {donor['type']}")

def search():
    print("\nSearch by blood type")
    for a, b in b_types.items():
        print(f"{a}. {b}")
    ch = input("Enter your choice (1-8): ")
    if ch not in b_types:
        print("Invalid blood type")
        return

    b_type = b_types[ch]
    fil = [x for x in donors if x["type"] == b_type]

    if not fil:
        print("No donors found with the blood type.")
        return

    print("\nDonors with the blood type", b_type)
    for x in fil:
        print_donor(x)

    while True:
        print("\nChoose filter method\n1. Gender\n2. State\n3. Exit filter")
        mtd = input("Choice (1-3): ")
        if mtd == "1":
            gender = ch_gender()
            result = [x for x in fil if x["gender"] == gender]
        elif mtd == "2":
            state = ch_state()
            result = [x for x in fil if x["state"] == state]
        elif mtd == "3":
            break
        else:
            print("Invalid option. Please enter 1 until 3")
            continue

        print("\nFiltered Donors:")
        if result:
            for x in result:
                print_donor(x)
        else:
            print("No matching donor")

while True:
    try:
        option = menu()

        if option == "1":
            add()
        elif option == "2":
            search()
        elif option == "3":
            print("Exiting Program")
            break
        else:
            print("Invalid Option")
    except Exception as e:
        print("An error occurred:", e)
