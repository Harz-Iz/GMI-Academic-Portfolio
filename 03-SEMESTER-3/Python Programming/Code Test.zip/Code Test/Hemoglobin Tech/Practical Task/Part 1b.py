def ctf_word_organizer_basic(text_string):

    #Split the string into a list of words
    all_words = text_string.split()

    # We use a helper list and a set to manually track uniqueness and maintain order.
    unique_ordered_words = []
    seen_words = set()

    for word in all_words:
        if word not in seen_words:
            unique_ordered_words.append(word)
            seen_words.add(word)

    #Separate the unique words into two groups
    key_words = []
    other_words = []
    KEY_PREFIX = "key_"

    for word in unique_ordered_words:
        if word.startswith(KEY_PREFIX):
            key_words.append(word)
        else:
            other_words.append(word)

    #Sort the 'key_' words alphabetically (default sort order)
    key_words.sort()

    #Sort all other words in reverse alphabetical order
    other_words.sort(reverse=True)

    #Define final variable with combine the two sorted lists
    final_sorted_list = key_words + other_words
    return final_sorted_list

#Define input (tk setup user input)
input_str_b = "noise1 key_alpha key_beta spg0453 python noise2 key_alpha noise1 noise7 noise10 hariz sir_ameer zap"
output_list_b = ctf_word_organizer_basic(input_str_b)

print(f"Input: {input_str_b}")
print(f"Output (CTF Organized - Basic): {output_list_b}")