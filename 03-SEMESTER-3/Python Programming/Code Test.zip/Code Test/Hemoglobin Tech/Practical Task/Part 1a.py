def custom_unique_word_sorter_vowels(text_string):

    words = text_string.split()
    unique_words = list(set(words))

    #Define vowels
    VOWELS = 'aeiouAEIOU'

    #Sorting function
    def sort_key(word):

        is_consonant_start = word[0] not in VOWELS
        return (is_consonant_start, word)

    unique_words.sort(key=sort_key)

    return unique_words

#Define input and output (tk setup user input)
input_str_a = "apple orange banana apple egg igloo banana"
output_list_a = custom_unique_word_sorter_vowels(input_str_a)

#Print defined input and output
print(f"Input: {input_str_a}") #Variable dkt line 20
print(f"Output (Vowels First): {output_list_a}") #Variable dkt line 12