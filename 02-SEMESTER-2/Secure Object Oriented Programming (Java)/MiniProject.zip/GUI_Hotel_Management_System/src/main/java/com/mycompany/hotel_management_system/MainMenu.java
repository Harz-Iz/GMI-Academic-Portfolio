/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import java.awt.*;

public class MainMenu {

    private static JFrame frame;
    private static JPanel cardPanel;
    private static CardLayout cardLayout;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu().createAndShowGUI());
    }
    
    public static void switchPanel(String panelName) {
        cardLayout.show(cardPanel, panelName);
    }

    private void createAndShowGUI() {
        frame = new JFrame("Hotel Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        cardPanel.add(new MainMenu().MainMenuPanel(), "MainMenu");
        cardPanel.add(new LoginPanel().getLoginPanel(), "LoginPanel");
        cardPanel.add(new Hotel_Admin().getAdminPanel(), "AdminMenu");
        cardPanel.add(new Front_Desk().getFrontDeskPanel(), "FrontDeskMenu");
        cardPanel.add(new Guests().getGuestsPanel(), "GuestsMenu");
        cardPanel.add(new Bookings().getBookingsPanelAdmin(), "AdminBookings");
        cardPanel.add(new Bookings().getBookingsPanelFD(), "FDBookings");
        cardPanel.add(new Employees().getEmployeesPanel(), "EmployeesMenu");
        cardPanel.add(new Rooms().getRoomsPanelAdmin(), "RoomsMenuAdmin");
        cardPanel.add(new Rooms().getRoomsPanelFD(), "RoomsMenuFD");

        frame.add(cardPanel);
        frame.setVisible(true);
    }
    
    public JPanel MainMenuPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    
        JLabel label = new JLabel("Hotel Management System", SwingConstants.CENTER);
        label.setFont(new Font("Times New Roman", Font.BOLD, 30));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        panel.add(Box.createVerticalStrut(30));
        panel.add(label);
        panel.add(Box.createVerticalStrut(50));
    
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        JButton adminButton = new JButton("Admin Access");
        JButton frontDeskButton = new JButton("Front Desk Access");
        JButton exitButton = new JButton("Exit");
    
        adminButton.addActionListener(e -> MainMenu.switchPanel("LoginPanel"));
        frontDeskButton.addActionListener(e -> MainMenu.switchPanel("FrontDeskMenu"));
        exitButton.addActionListener(e -> System.exit(0));
    
        adminButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        frontDeskButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        buttonPanel.add(adminButton);
        buttonPanel.add(Box.createVerticalStrut(15));
        buttonPanel.add(frontDeskButton);
        buttonPanel.add(Box.createVerticalStrut(15));
        buttonPanel.add(exitButton);
    
        panel.add(buttonPanel);
        
        return panel;
    }
}