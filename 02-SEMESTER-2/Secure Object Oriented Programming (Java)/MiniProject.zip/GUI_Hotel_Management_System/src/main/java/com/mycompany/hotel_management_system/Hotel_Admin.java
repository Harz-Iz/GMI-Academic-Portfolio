/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Hotel_Admin {

    private String selectedOption;

    public JPanel getAdminPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Admin Menu", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(label, BorderLayout.NORTH);

        // Create radio buttons
        JRadioButton viewEmployeesButton = new JRadioButton("View Employees");
        JRadioButton manageRoomsButton = new JRadioButton("Manage Rooms");
        JRadioButton manageBookingsButton = new JRadioButton("Manage Bookings");

        // Group the radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(viewEmployeesButton);
        group.add(manageRoomsButton);
        group.add(manageBookingsButton);

        // Add action listeners to store selection
        viewEmployeesButton.addActionListener(e -> selectedOption = "EmployeesMenu");
        manageRoomsButton.addActionListener(e -> selectedOption = "RoomsMenuAdmin");
        manageBookingsButton.addActionListener(e -> selectedOption = "AdminBookings");

        // Panel for radio buttons
        JPanel radioPanel = new JPanel(new GridLayout(0, 1, 10, 10));
        radioPanel.add(viewEmployeesButton);
        radioPanel.add(manageRoomsButton);
        radioPanel.add(manageBookingsButton);

        // Continue button
        JButton continueButton = new JButton("Continue");
        continueButton.addActionListener(e -> {
            if (selectedOption != null) {
                MainMenu.switchPanel(selectedOption);
            } else {
                JOptionPane.showMessageDialog(panel, "Please select an option first");
            }
        });

        // Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> MainMenu.switchPanel("MainMenu"));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(continueButton);
        buttonPanel.add(backButton);

        // Main content panel
        JPanel contentPanel = new JPanel(new BorderLayout(10, 20));
        contentPanel.add(radioPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        panel.add(contentPanel, BorderLayout.CENTER);

        return panel;
    }
}