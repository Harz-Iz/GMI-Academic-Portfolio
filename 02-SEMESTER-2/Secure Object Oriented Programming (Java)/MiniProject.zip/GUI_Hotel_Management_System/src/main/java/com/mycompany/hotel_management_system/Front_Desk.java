/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Front_Desk {

    private String selectedOption;

    public JPanel getFrontDeskPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Front Desk Menu", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(label, BorderLayout.NORTH);

        // Create radio buttons
        JRadioButton checkVacanciesButton = new JRadioButton("Check Vacancies");
        JRadioButton checkInButton = new JRadioButton("Check-in Guest");

        // Group the radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(checkVacanciesButton);
        group.add(checkInButton);

        // Add action listeners to store selection
        checkVacanciesButton.addActionListener(e -> selectedOption = "RoomsMenuFD");
        checkInButton.addActionListener(e -> selectedOption = "FDBookings");

        // Panel for radio buttons
        JPanel radioPanel = new JPanel(new GridLayout(0, 1, 10, 10));
        radioPanel.add(checkVacanciesButton);
        radioPanel.add(checkInButton);

        // Continue button
        JButton continueButton = new JButton("Continue");
        continueButton.addActionListener(e -> {
            if (selectedOption != null) {
                MainMenu.switchPanel(selectedOption);
            } else {
                JOptionPane.showMessageDialog(panel, "Please select an option first");
            }
        });

        // Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> MainMenu.switchPanel("MainMenu"));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(continueButton);
        buttonPanel.add(backButton);

        // Main content panel
        JPanel contentPanel = new JPanel(new BorderLayout(10, 20));
        contentPanel.add(radioPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        panel.add(contentPanel, BorderLayout.CENTER);

        return panel;
    }
}