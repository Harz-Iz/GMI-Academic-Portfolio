/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

    public class Rooms {
    private static DefaultTableModel tableModel;
    private JTable roomTable;
    private int roomCounter = 1;

    public Rooms() {
    if (tableModel == null) {
        String[] columns = {"Room No", "Room Type", "Bed Type", "Vacancy"};
        tableModel = new DefaultTableModel(columns, 0); // Empty table by default
    }
}
    
        // Room Status Function
    public static void updateRoomStatus(String roomNo, String status) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(roomNo)) {
                tableModel.setValueAt(status, i, 3); // Column 3 is "Vacancy"
                break;
            }
        }
    }

    public static boolean isRoomAvailable(String roomNo) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(roomNo)) {
                return "Available".equals(tableModel.getValueAt(i, 3));
            }
        }
        return false;
    }

    public static String[] getAvailableRooms() {
        java.util.List<String> rooms = new java.util.ArrayList<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ("Available".equals(tableModel.getValueAt(i, 3))) {
                rooms.add((String) tableModel.getValueAt(i, 0));
            }
        }
        return rooms.toArray(new String[0]);
    }


    public JPanel getRoomsPanelAdmin() {
        return createRoomManagementPanel("AdminMenu", true);
    }

    public JPanel getRoomsPanelFD() {
        return createRoomManagementPanel("FrontDeskMenu", false);
    }

    private JPanel createRoomManagementPanel(String backPanel, boolean isAdmin) {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel label = new JLabel("Room Management", SwingConstants.CENTER);
        panel.add(label, BorderLayout.NORTH);

        roomTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(roomTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        if (isAdmin) {
            JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
            formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Expanded Room Type options
            JComboBox<String> roomTypeBox = new JComboBox<>(new String[]{
                "Standard", "Deluxe", "Suite", "Executive", "Presidential", "Family", "Single", "Double"
            });

            // Expanded Bed Type options
            JComboBox<String> bedTypeBox = new JComboBox<>(new String[]{
                "Single", "Double", "Queen", "King", "Twin", "Bunk", "Sofa Bed", "Murphy Bed"
            });

            formPanel.add(new JLabel("Room Type:"));
            formPanel.add(roomTypeBox);
            formPanel.add(new JLabel("Bed Type:"));
            formPanel.add(bedTypeBox);

            panel.add(formPanel, BorderLayout.WEST);

            JPanel buttonPanel = new JPanel();

            JButton addBtn = new JButton("Save");
            addBtn.addActionListener((ActionEvent e) -> {
                String roomType = (String) roomTypeBox.getSelectedItem();
                String bedType = (String) bedTypeBox.getSelectedItem();
                tableModel.addRow(new Object[]{"R" + String.format("%04d", roomCounter++), roomType, bedType, "Available"});
            });
            buttonPanel.add(addBtn);

            JButton editBtn = new JButton("Edit");
            editBtn.addActionListener((ActionEvent e) -> {
                int selectedRow = roomTable.getSelectedRow();
                if (selectedRow >= 0) {
                    tableModel.setValueAt(roomTypeBox.getSelectedItem(), selectedRow, 1);
                    tableModel.setValueAt(bedTypeBox.getSelectedItem(), selectedRow, 2);
                } else {
                    JOptionPane.showMessageDialog(panel, "Select a row to edit.");
                }
            });
            buttonPanel.add(editBtn);

            JButton deleteBtn = new JButton("Delete");
            deleteBtn.addActionListener((ActionEvent e) -> {
                int selectedRow = roomTable.getSelectedRow();
                if (selectedRow >= 0) {
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(panel, "Select a row to delete.");
                }
            });
            buttonPanel.add(deleteBtn);

            JButton backBtn = new JButton("Back");
            backBtn.addActionListener(e -> MainMenu.switchPanel(backPanel));
            buttonPanel.add(backBtn);

            panel.add(buttonPanel, BorderLayout.SOUTH);
        } else {
            JPanel buttonPanel = new JPanel();
            JButton backBtn = new JButton("Back");
            backBtn.addActionListener(e -> MainMenu.switchPanel(backPanel));
            buttonPanel.add(backBtn);
            panel.add(buttonPanel, BorderLayout.SOUTH);
        }

        return panel;
    }
}