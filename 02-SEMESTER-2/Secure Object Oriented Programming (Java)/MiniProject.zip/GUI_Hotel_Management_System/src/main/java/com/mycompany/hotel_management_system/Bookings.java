/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Bookings {
    private static DefaultTableModel tableModel;
    private JTable bookingsTable;

    public Bookings() {
        if (tableModel == null) {
            String[] columns = {"Booking ID", "Guest Name", "Room No", "Check-In", "Check-Out", "Status"};
            tableModel = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Make table non-editable
                }
            };
        }
    }

    public JPanel getBookingsPanelAdmin() {
        return createBookingsPanel(true);
    }

    public JPanel getBookingsPanelFD() {
        return createBookingsPanel(false);
    }

    private JPanel createBookingsPanel(boolean isAdmin) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JLabel label = new JLabel("Booking Management", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(label, BorderLayout.NORTH);

        bookingsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookingsTable);
        panel.add(scrollPane, BorderLayout.CENTER);

          JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton addButton = new JButton("Add Booking");
        addButton.addActionListener(e -> addBooking());

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> MainMenu.switchPanel(isAdmin ? "AdminMenu" : "FrontDeskMenu"));

        buttonPanel.add(addButton);

        if (isAdmin) {
            JButton removeButton = new JButton("Remove Booking");
            removeButton.addActionListener(e -> removeBooking());
            buttonPanel.add(removeButton);
        }

        buttonPanel.add(backButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void viewBookings() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "No bookings found.", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    }

        // In Bookings.java
    private void addBooking() {
        String[] availableRooms = Rooms.getAvailableRooms();
        if (availableRooms.length == 0) {
            JOptionPane.showMessageDialog(null, "No available rooms!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));

        JTextField guestNameField = new JTextField();
        JComboBox<String> roomCombo = new JComboBox<>(availableRooms);
        JTextField checkInField = new JTextField();
        JTextField checkOutField = new JTextField();

        formPanel.add(new JLabel("Guest Name:"));
        formPanel.add(guestNameField);
        formPanel.add(new JLabel("Room No:"));
        formPanel.add(roomCombo);
        formPanel.add(new JLabel("Check-In Date:"));
        formPanel.add(checkInField);
        formPanel.add(new JLabel("Check-Out Date:"));
        formPanel.add(checkOutField);

        int result = JOptionPane.showConfirmDialog(null, formPanel, 
                "Add New Booking", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            String roomNo = (String) roomCombo.getSelectedItem();
            String bookingId = "B" + System.currentTimeMillis();
            tableModel.addRow(new Object[]{
                bookingId,
                guestNameField.getText(),
                roomNo,
                checkInField.getText(),
                checkOutField.getText(),
                "Confirmed"
            });
            Rooms.updateRoomStatus(roomNo, "Occupied");
        }
    }

    private void removeBooking() {
        int selectedRow = bookingsTable.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(null, 
                    "Are you sure you want to delete this booking?", 
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String roomNo = (String) tableModel.getValueAt(selectedRow, 2);
                tableModel.removeRow(selectedRow);
                Rooms.updateRoomStatus(roomNo, "Available");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a booking to remove.");
        }
    }
}