/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import java.awt.*;

public class Guests {

    static DefaultListModel<String> guestListModel = new DefaultListModel<>();
    static JList<String> guestList = new JList<>(guestListModel);

    public JPanel getGuestsPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel label = new JLabel("Guest Management", SwingConstants.CENTER);
        panel.add(label, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane(guestList);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JButton addButton = new JButton("Add Guest");
        JButton removeButton = new JButton("Remove Guest");
        JButton backButton = new JButton("Back");

        addButton.addActionListener(e -> addGuest());
        removeButton.addActionListener(e -> removeGuest());
        backButton.addActionListener(e -> MainMenu.switchPanel("AdminMenu"));

        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(backButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void addGuest() {
        String guestName = JOptionPane.showInputDialog("Enter Guest Name:");
        if (guestName != null && !guestName.trim().isEmpty()) {
            guestListModel.addElement(guestName);
            JOptionPane.showMessageDialog(null, "Guest added: " + guestName);
        } 

        if (guestName == null ) { 
            JOptionPane.showMessageDialog(null, "Cancelled" );
            System.exit(1);
        } else {
            JOptionPane.showMessageDialog(null, "Invalid Guest Name.");
        }
    }

    private void removeGuest() {
        String guestName = JOptionPane.showInputDialog("Enter Guest Name to remove:");
        if (guestName != null && guestListModel.contains(guestName)) {
            guestListModel.removeElement(guestName);
            JOptionPane.showMessageDialog(null, "Guest removed: " + guestName);
        } else {
            JOptionPane.showMessageDialog(null, "Guest not found.");
        }
    }
}