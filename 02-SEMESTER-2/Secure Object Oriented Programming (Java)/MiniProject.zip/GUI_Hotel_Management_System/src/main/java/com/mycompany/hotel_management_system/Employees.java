/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel_management_system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Employees {

    private DefaultTableModel tableModel;
    private JTable employeeTable;

    public JPanel getEmployeesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JLabel label = new JLabel("On-Duty Employees", SwingConstants.CENTER);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        String[] columns = {"Name", "Position"};
        tableModel = new DefaultTableModel(columns, 0);
        employeeTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(employeeTable);

        addEmployee("Farhan", "Manager");
        addEmployee("Hannie", "Receptionist");
        addEmployee("Aiman", "Housekeeping");
        addEmployee("Putri", "Security");

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(10);
        JLabel positionLabel = new JLabel("Position:");
        JTextField positionField = new JTextField(10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);
        gbc.gridx = 2;
        formPanel.add(positionLabel, gbc);
        gbc.gridx = 3;
        formPanel.add(positionField, gbc);

        JPanel buttonPanel = new JPanel(new GridBagLayout());

        JButton clockInBtn = new JButton("Clock-In");
        clockInBtn.setPreferredSize(new Dimension(100, 30));
        clockInBtn.addActionListener((ActionEvent e) -> {
            String name = nameField.getText().trim();
            String position = positionField.getText().trim();

            if (name.isEmpty() || position.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Please enter both name and position.");
                return;
            }

            addEmployee(name, position);
            nameField.setText("");
            positionField.setText("");
        });

        JButton clockOutBtn = new JButton("Clock-Out");
        clockOutBtn.setPreferredSize(new Dimension(100, 30));
        clockOutBtn.addActionListener((ActionEvent e) -> {
            int selectedRow = employeeTable.getSelectedRow();
            if (selectedRow >= 0) {
                tableModel.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(panel, "Please select an employee to clock out.");
            }
        });

        JButton backBtn = new JButton("Back");
        backBtn.setPreferredSize(new Dimension(100, 30));
        backBtn.addActionListener(e -> MainMenu.switchPanel("AdminMenu"));

        gbc.gridx = 0;
        gbc.gridy = 0;
        buttonPanel.add(clockInBtn, gbc);
        gbc.gridx = 1;
        buttonPanel.add(clockOutBtn, gbc);
        gbc.gridx = 2;
        buttonPanel.add(backBtn, gbc);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.add(Box.createVerticalStrut(10));
        topPanel.add(label);
        topPanel.add(Box.createVerticalStrut(10));
        topPanel.add(formPanel);
        topPanel.add(Box.createVerticalStrut(10));
        topPanel.add(buttonPanel);
        topPanel.add(Box.createVerticalStrut(10));

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void addEmployee(String name, String position) {
        tableModel.addRow(new Object[]{name, position});
    }
}